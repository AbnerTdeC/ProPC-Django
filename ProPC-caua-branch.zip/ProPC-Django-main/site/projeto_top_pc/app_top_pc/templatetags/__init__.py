# This file is required to make templatetags a Python package
