from django.contrib import admin
from .models import *

# Register your models here.

admin.site.register(Componente)
admin.site.register(LinkComponente)
admin.site.register(EstatisticaComponente)