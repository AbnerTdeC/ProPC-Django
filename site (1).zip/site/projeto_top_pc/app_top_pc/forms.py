from django import forms
from .models import Componente

class ComponenteForm(forms.ModelForm):
    class Meta:
        model = Componente
        fields = ['nome', 'icone', 'lancamento', 'preco', 'classificacao', 'tipo']
        widgets = {
            'lancamento': forms.DateInput(
                format=('%Y-%m-%d'), # Formato que o DateInput espera e que o HTML type="date" usa
                attrs={
                    'type': 'date', # Para usar o seletor de data nativo do navegador
                    'class': 'form-control' # Opcional: para estilização com Bootstrap, por exemplo
                }
            ),
            'nome': forms.TextInput(attrs={'class': 'form-control'}),
            'icone': forms.URLInput(attrs={'class': 'form-control'}),
            'preco': forms.NumberInput(attrs={'class': 'form-control'}),
            'classificao': forms.NumberInput(attrs={'class': 'form-control', 'min': '0', 'max': '5'}), # Exemplo: classificação de 0 a 5
            'tipo': forms.Select(attrs={'class': 'form-control'}),
        }
        labels = {
            'nome': 'Nome do Componente',
            'icone': 'URL do Ícone',
            'lancamento': 'Data de Lançamento',
            'preco': 'Preço (R$)',
            'classificao': 'Classificação (0-5)',
            'tipo': 'Tipo de Componente',
        }
        help_texts = {
            'preco': 'Informe o preço em Reais (ex: 1250.99).',
            'classificao': 'Dê uma nota de 0 a 5 para o componente.',
            'icone': 'Cole a URL completa da imagem do ícone (ex: https://site.com/imagem.png).'
        }
        error_messages = {
            'nome': {
                'max_length': "O nome do componente é muito longo.",
                'required': "O nome do componente é obrigatório."
            },
            'preco': {
                'invalid': "Por favor, insira um valor numérico válido para o preço."
            }
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Você pode adicionar personalizações adicionais aqui se necessário
        # Por exemplo, se você não quiser adicionar a classe 'form-control' via widgets para todos:
        # for field_name, field in self.fields.items():
        #     if not field.widget.attrs.get('class'):
        #          field.widget.attrs.update({'class': 'form-control'})