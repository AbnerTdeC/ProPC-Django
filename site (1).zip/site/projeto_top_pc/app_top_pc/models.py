from django.db import models

# Create your models here.

class Componente(models.Model):
    TIPO_CHOICES = [
        ('CPU', 'CPU'),
        ('GPU', 'GPU'),
        ('Placa-mãe', 'Placa-mãe'),
        ('RAM', 'RAM'),
        ('Armazenamento', 'Armazenamento'),
        # adicione outros tipos conforme necessário
    ]
    
    nome = models.CharField(max_length=50)
    icone = models.URLField()
    lancamento = models.DateField()
    preco = models.FloatField()
    classificacao = models.IntegerField()
    tipo = models.CharField(max_length=20, choices=TIPO_CHOICES, default="CPU")


    def __str__(self):
        return self.nome

class LinkComponente(models.Model):
    link = models.URLField()
    descricao = models.CharField(max_length=100)
    Componente = models.ForeignKey(Componente, on_delete=models.CASCADE)
    def __str__(self):
        return self.link

class EstatisticaComponente(models.Model):
    componente = models.ForeignKey(Componente, on_delete=models.CASCADE)
    benchmark = models.IntegerField()
    eficiencia_energetica = models.DecimalField(max_digits=5, decimal_places=2)
    observacao = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"Estatísticas de {self.componente.nome}"