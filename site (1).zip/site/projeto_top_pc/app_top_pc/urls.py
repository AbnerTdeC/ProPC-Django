from django.urls import path
from . import views  # Garante que suas views estão sendo importadas do local correto

app_name = 'app_top_pc'  # Define o namespace do aplicativo

urlpatterns = [
    # URL para a página inicial do seu aplicativo
    path('', views.home, name='home'),
    
    # URLs para as funcionalidades de Componente
    path('componente/adicionar/', views.cadastrar_componente, name='adicionar_componente'),
    path('componente/editar/<int:id>/', views.editar_componente, name='editar_componente'),
    path('componente/remover/<int:id>/', views.remover_componente, name='remover_componente'),
]