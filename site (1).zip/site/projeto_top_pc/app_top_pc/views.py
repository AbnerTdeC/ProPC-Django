from collections import defaultdict
from django.shortcuts import render, redirect, get_object_or_404 # Adicione redirect
from .models import * # Componente já está importado aqui
from .forms import ComponenteForm # Importe o seu formulário

# Create your views here.

def home(request):
    componentes = Componente.objects.all()
    
    componentes_por_tipo = defaultdict(list)
    for componente in componentes:
        componentes_por_tipo[componente.tipo].append(componente)

    estatisticas = EstatisticaComponente.objects.all() #

    context = {
        "nome": "Abner Raphael Tosta de Castro", #
        "componentes": componentes_por_tipo, #
        "lista_cpu": componentes_por_tipo["CPU"], #
        "estatisticas": estatisticas, #
    }

    return render(request, "app_top_pc/index.html", context) #


def old_home(request):
    
    lista_cpu = [
    {
        "nome": "Ryzen 9 9950x3d", #
        "icone": "https://m.media-amazon.com/images/I/71hZfMZNZuL._AC_UF894,1000_QL80_.jpg", #
    },
    {
        "nome": "Ryzen 9 9900x3d", #
        "icone": "https://m.media-amazon.com/images/I/71hZfMZNZuL._AC_UF894,1000_QL80_.jpg", #
    },
    {
        "nome": "Ryzen 7 9800x3d", #
        "icone": "https://cdn.wccftech.com/wp-content/uploads/2024/10/AMD-Ryzen-7-7800X3D-3D-V-Cache-CPU-Box-_1-1279x1456.jpeg", #
    }
    ]

    context = {
            "nome": "Abner Raphael Tosta de Castro", #
            "lista_cpu": lista_cpu, #
        }
    return render(request, "index.html", context) #

def cadastrar_componente(request):
    if request.method == 'POST':
        form = ComponenteForm(request.POST, request.FILES) # Adicione request.FILES se seu formulário lida com uploads de arquivos (não é o caso do ComponenteForm atual, mas é uma boa prática se houver campos FileField/ImageField)
        if form.is_valid():
            form.save()
            # Redireciona para a página inicial após o cadastro bem-sucedido.
            # Você pode mudar 'home' para o nome da URL da sua lista de componentes ou outra página de sucesso.
            return redirect('home') # Assumindo que você tem uma URL com name='home' para a sua view home.
    else:
        form = ComponenteForm()
    
    # Crie um template para este formulário, por exemplo: 'nome_do_seu_app/cadastrar_componente.html'
    # O nome do template 'cadastrar_componente.html' é um exemplo.
    return render(request, 'app_top_pc/cadastrar_componente.html', {'form': form})

def editar_componente(request, id):
    componente = get_object_or_404(Componente, pk=id)
    if request.method == 'POST':
        form = ComponenteForm(request.POST, request.FILES, instance=componente)
        # request.FILES é para o caso de você adicionar campos de upload de arquivo no futuro
        if form.is_valid():
            form.save()
            return redirect('home') # Redireciona para a página principal
    else:
        form = ComponenteForm(instance=componente) # Preenche o formulário com dados do componente existente
    
    return render(request, 'app_top_pc/editar_componente.html', {'form': form, 'componente': componente})

def remover_componente(request, id):
    componente = get_object_or_404(Componente, pk=id)
    if request.method == 'POST':
        componente.delete()
        return redirect('app_top_pc:home') 

    return render(request, 'app_top_pc/remover_componente.html', {'componente': componente}) # Linha CORRIGIDA